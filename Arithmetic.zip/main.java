public class main {
    public static void main (String args[])
    {
    System.out.println("Hello");
    
        int lengthroom = 18; 
        int widthroom = 12; 
        int area = widthroom * lengthroom; 
        System.out.println("#6: The are of the room is: " + area + " feet.");
        
    }
 }
