class Sound
{
    public static void main(String args[])
    {
        double dist;
        dist = 7.2 * 1100; 
        //1100 is the rate of travel(in feet) of sound per second through air 
        //7.2 is the seconds it takes to travel to the distination 
        //therefore 1100 has to be timed by 7.2 to achieve how far away the lighting is
        System.out.println("The lightning is " + dist 
        + " feet away.");

    }
}