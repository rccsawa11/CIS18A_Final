//Part B of Lab 2 Race Car Program
public class raceTrack

{
    public static void main (String args[])
    {
        double radiusTrack = 1.3; 
        double circuTrack = 2 * radiusTrack * Math.PI; 
        double distanceFinal = circuTrack * 5; 
        System.out.println("The total ditance traveled by the race car is " 
        + distanceFinal + " miles.");
    }
}

// I like to make my programs flexible-
// like if I wanted to change individual-
// values at will later 