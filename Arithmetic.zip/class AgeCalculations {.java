class AgeCalculations {
    int[] ages; // store ages of friends and family
   
    AgeCalculations(int[] a) { // initializing the ages array
     ages = a;
    }
   
    class InnerAgeCalc { // Inner class to perform calculations
     int min() { // Method to calculate minimum age
      int m = ages[0]; 
      for (int i = 1; i < ages.length; i++) { 
       if (ages[i] < m) 
        m = ages[i];
      }
      return m;
     }
   
     int max() { // Method to calculate maximum age
      int mx = ages[0];  
      for (int i = 1; i < ages.length; i++) {  
       if (ages[i] > mx) 
        mx = ages[i];
      }
      return mx;
     }
   
     int avg() { // Method to calculate average age
      int sum = 0; 
      for (int i = 0; i < ages.length; i++) 
       sum += ages[i]; 
      return sum / ages.length; 
     }
    }
   
    void calculate() { // Method to display the calculated values
     InnerAgeCalc iac = new InnerAgeCalc(); 
     System.out.println("Minimum Age: " + iac.min()); 
     System.out.println("Maximum Age: " + iac.max()); 
     System.out.println("Average Age: " + iac.avg()); 
    }
   
    public static void main(String[] args) { // Main method
     int[] friendsAndFamily = {25, 32, 40, 18, 60}; // Array of ages
     AgeCalculations ac = new AgeCalculations (friendsAndFamily); 
     ac.calculate(); // Call method to perform calculations
     System.out.println("Done calculating!"); 
    }
   }
   
