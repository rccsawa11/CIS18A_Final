import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
public class SwingFC implements ActionListener {
    JTextField jtfFirst, jtfSecond;
    JButton jbtnComp; 
    JLabel jlabFirst, jlabSecond;
    JLabel jlabResult; 
    SwingFC() {
        JFrame jfrm = new JFrame("Compare Files");
        jfrm.setLayout(new FlowLayout());
        jfrm.setSize(200, 150);
        jfrm.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        jtfFirst = new JTextField(14);
        jtfSecond = new JTextField(14);
        jtfFirst.setActionCommand("fileA");
        j the Compare button.
        JButton btnComp = new JButton("Compare");
        jfrm.add(jtfFirst);
        jfrm.add(jtfSecond);
        jfrm.add(btnComp);
        jlabFirst = new JLabel("First file: ");
        jlabSecond = new JLabel("Second file: ");
        jlabResult = new JLabel("");
        jfrm.add(jlabFirst);
        jfrm.add(jlabSecond);
        jfrm.add(jlabResult);
        jfrm.setVisible(true);
        jtfFirst.addActionListener(this);
        jtfSecond.addActionListener(this);
        btnComp.addActionListener(this);
    }

    public void actionPerformed(ActionEvent ae) {
        String actionCmd = ae.getActionCommand();

        if (actionCmd.equals("Compare")) {
            String firstFile = jtfFirst.getText();
            String secondFile = jtfSecond.getText();

            if (firstFile.equals(secondFile)) {
                jlabResult.setText("Files are the same.");
            } else {
                jlabResult.setText("Files are different.");
            }
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                new SwingFC();
            }
        });
    }
}