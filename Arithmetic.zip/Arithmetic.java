class Arithmetic 
{
    public static void main (String args[])
    {
        int myVar1 = 5;
        int myVar2 = myVar1 + 1; 
        System.out.println("A-B. myVar1 = " + 
        myVar1 + " and myVar2 = " + myVar2);

       // int myVar2 = myVar2 * 10; 
       // System.out.println("C-D. MyVar2 now = " + myVar2);
    }
}
